import { createPool, type PoolConnection, type ResultSetHeader, type RowDataPacket } from 'mysql2/promise';
import { env } from './env.js';

export const pool = createPool({
  host: env.db.host, port: env.db.port, user: env.db.user, password: env.db.password, database: env.db.database,
  waitForConnections: true, connectionLimit: env.db.poolSize, queueLimit: env.db.queueLimit, connectTimeout: env.db.connectTimeoutMs, charset: 'utf8mb4',
  supportBigNumbers: true, bigNumberStrings: true, dateStrings: true,
});

export async function query<T extends RowDataPacket[]>(sql: string, params: any[] = []): Promise<T> {
  const [rows] = await pool.execute<T>(sql, params);
  return rows;
}

export async function execute(sql: string, params: any[] = []): Promise<ResultSetHeader> {
  const [result] = await pool.execute<ResultSetHeader>(sql, params);
  return result;
}

export async function transaction<T>(work: (connection: PoolConnection) => Promise<T>): Promise<T> {
  const connection = await pool.getConnection();
  try { await connection.beginTransaction(); const value = await work(connection); await connection.commit(); return value; }
  catch (error) { await connection.rollback(); throw error; }
  finally { connection.release(); }
}

export async function transactionWithDeadlockRetry<T>(work:(connection:PoolConnection)=>Promise<T>,maxAttempts=3):Promise<T>{
  for(let attempt=1;;attempt++){
    try{return await transaction(work)}catch(error){
      const code=error&&typeof error==='object'&&'code'in error?String(error.code):'';
      if(code!=='ER_LOCK_DEADLOCK'||attempt>=maxAttempts)throw error;
    }
  }
}
