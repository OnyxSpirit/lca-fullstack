import React,{useEffect,useState}from'react';
import{Archive,Bell,CheckCheck}from'lucide-react';
import{useNavigate}from'react-router-dom';
import{formatNotificationDate,useNotificationActions,useNotificationsQuery}from'../../api/notificationHooks';
import{PageHeader}from'../../components/common/PageHeader';
import{Badge}from'../../components/ui/Badge';
import{Button}from'../../components/ui/Button';
import{Card}from'../../components/ui/Card';
import{useAuthStore}from'../../stores/authStore';
import{useUiStore}from'../../stores/uiStore';
import{canNavigateWithPermissions}from'../../navigation/permissions';
import{notificationCategories,notificationScopeLabels,notificationScopesFor,type NotificationScope}from'./notificationFilters';

const PAGE_SIZE=5;

export const NotificationsPage:React.FC=()=>{
  const[page,setPage]=useState(1),[scope,setScope]=useState<NotificationScope>('mine'),[unreadOnly,setUnreadOnly]=useState(false),[referenceType,setReferenceType]=useState('');
  const currentUser=useAuthStore(s=>s.currentUser),can=useAuthStore(s=>s.can),permissionScope=useAuthStore(s=>s.permissionScope('notifications.view')),canUpdate=can('notifications.update'),canArchive=can('notifications.archive'),availableScopes=notificationScopesFor(permissionScope);
  useEffect(()=>{if(!availableScopes.includes(scope)){setScope(availableScopes[0]??'mine');setPage(1)}},[availableScopes,scope]);
  const query=useNotificationsQuery({page,pageSize:PAGE_SIZE,scope,unreadOnly,referenceType},can('notifications.view')),actions=useNotificationActions(),navigate=useNavigate(),toast=useUiStore(s=>s.addToast),data=query.data;
  const filters=notificationCategories.filter(([, ,permission])=>can(permission));
  const safe=async(action:()=>Promise<unknown>,route?:string)=>{try{await action();if(route&&canNavigateWithPermissions(currentUser.permissions,route))navigate(route)}catch(error){toast({type:'error',title:'Notification non mise à jour',description:error instanceof Error?error.message:'Erreur API'})}};
  return <div className="space-y-6">
    <PageHeader title="Notifications" subtitle="Alertes métier internes et persistantes." breadcrumbs={[{label:'Accueil',href:'/dashboard'},{label:'Notifications'}]} actions={canUpdate?<Button size="sm" variant="outline" icon={<CheckCheck className="h-4 w-4"/>} disabled={!data?.unreadCount} onClick={()=>safe(()=>actions.markAllAsRead.mutateAsync())}>Tout marquer comme lu</Button>:undefined}/>
    <div className="space-y-2"><div className="flex flex-wrap items-center gap-2"><span className="w-20 text-xs font-semibold text-slate-500">Portée</span>{availableScopes.map(value=><Button key={value} size="xs" variant={scope===value?'primary':'outline'} aria-pressed={scope===value} onClick={()=>{setScope(value);setPage(1)}}>{notificationScopeLabels[value]}</Button>)}</div><div className="flex flex-wrap items-center gap-2"><span className="w-20 text-xs font-semibold text-slate-500">Statut</span><Button size="xs" variant={!unreadOnly?'primary':'outline'} aria-pressed={!unreadOnly} onClick={()=>{setUnreadOnly(false);setPage(1)}}>Toutes</Button><Button size="xs" variant={unreadOnly?'primary':'outline'} aria-pressed={unreadOnly} onClick={()=>{setUnreadOnly(true);setPage(1)}}>Non lues ({data?.unreadCount??0})</Button></div><div className="flex flex-wrap items-center gap-2"><span className="w-20 text-xs font-semibold text-slate-500">Catégorie</span><Button size="xs" variant={!referenceType?'primary':'outline'} aria-pressed={!referenceType} onClick={()=>{setReferenceType('');setPage(1)}}>Tous les types</Button>{filters.map(([value,label])=><Button key={value} size="xs" variant={referenceType===value?'primary':'outline'} aria-pressed={referenceType===value} onClick={()=>{setReferenceType(value);setPage(1)}}>{label}</Button>)}</div></div>
    {query.isError&&<div className="rounded border border-red-200 bg-red-50 p-3 text-sm text-red-800">{query.error.message}</div>}
    <Card padding="none"><div className="divide-y">{data?.items.map(n=>{const navigable=canNavigateWithPermissions(currentUser.permissions,n.linkRoute),personal=scope==='mine';return <div key={n.id} className={`flex gap-3 p-4 ${n.isRead?'bg-white':'bg-red-50/30'}`}><Bell className="mt-0.5 h-5 w-5 text-[#8f1722]"/><button className={`flex-1 text-left ${navigable?'cursor-pointer':'cursor-default'}`} title={navigable?undefined:'Destination non accessible avec vos permissions'} onClick={()=>safe(()=>!personal||n.isRead||!canUpdate?Promise.resolve():actions.markAsRead.mutateAsync(n.id),navigable?n.linkRoute:undefined)}><div className="flex items-center gap-2"><b className="text-sm">{n.subject}</b><Badge size="xs" variant={n.priority==='urgent'?'danger':n.priority==='high'?'warning':'default'}>{n.eventType??n.referenceType??'Système'}</Badge></div><p className="mt-1 text-xs text-slate-600">{n.message}</p><span className="text-[10px] text-slate-400">{formatNotificationDate(n.createdAt)}</span></button>{personal&&canArchive&&<Button size="xs" variant="ghost" icon={<Archive className="h-3.5 w-3.5"/>} onClick={()=>safe(()=>actions.archiveNotification.mutateAsync(n.id))}>Archiver</Button>}</div>})}{!query.isLoading&&!data?.items.length&&<p className="p-8 text-center text-sm text-slate-500">Aucune notification.</p>}</div><div className="flex justify-between border-t p-3 text-xs"><span>{data?.total??0} résultat(s)</span><div className="flex gap-2"><Button size="xs" variant="outline" disabled={page<=1} onClick={()=>setPage(x=>x-1)}>Précédent</Button><span>Page {page} / {Math.max(1,Math.ceil((data?.total??0)/PAGE_SIZE))}</span><Button size="xs" variant="outline" disabled={page*PAGE_SIZE>=(data?.total??0)} onClick={()=>setPage(x=>x+1)}>Suivant</Button></div></div></Card>
  </div>;
};
