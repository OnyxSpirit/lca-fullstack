import React, { useEffect, useState } from "react";
import { Search } from "lucide-react";
import {
  useBaySettingsActions,
  useSettingsBaysQuery,
  useSupplierSettingsActions,
  useSuppliersSettingsQuery,
  type Bay,
  type Supplier,
  type SupplierInput,
} from "../../api/resourceSettingsHooks";
import { Badge } from "../../components/ui/Badge";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { useAuthStore } from "../../stores/authStore";
import { useUiStore } from "../../stores/uiStore";
const field = "rounded-md border border-slate-300 px-3 py-2 text-sm",
  emptySupplier: SupplierInput = {
    name: "",
    code: "",
    contactName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    country: "",
    taxIdentifier: "",
    isActive: true,
    isPartsSupplier: true,
    isVehicleSupplier: false,
  };
export const SuppliersSettings = () => {
  const canManage = useAuthStore((s) => s.can("parts.suppliers.manage"));
  const [search, setSearch] = useState(""),
    [debounced, setDebounced] = useState(""),
    [form, setForm] = useState<SupplierInput>(emptySupplier),
    [editing, setEditing] = useState<string | null>(null),
    q = useSuppliersSettingsQuery(debounced),
    actions = useSupplierSettingsActions(),
    toast = useUiStore((s) => s.addToast);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);
  const fail = (e: unknown) =>
    toast({
      type: "error",
      title: "Opération fournisseur impossible",
      description: e instanceof Error ? e.message : "Erreur API",
    });
  const edit = (s: Supplier) => {
    setEditing(s.id);
    setForm({
      name: s.name,
      code: s.code,
      contactName: s.contact_name ?? "",
      email: s.email ?? "",
      phone: s.phone ?? "",
      address: s.address ?? "",
      city: s.city ?? "",
      country: s.country ?? "",
      taxIdentifier: s.tax_identifier ?? "",
      isActive: s.is_active,
      isPartsSupplier: s.is_parts_supplier,
      isVehicleSupplier: s.is_vehicle_supplier,
    });
  };
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      editing
        ? await actions.update.mutateAsync({ id: editing, ...form })
        : await actions.create.mutateAsync(form);
      setEditing(null);
      setForm(emptySupplier);
      toast({
        type: "success",
        title: editing ? "Fournisseur modifié" : "Fournisseur créé",
      });
    } catch (x) {
      fail(x);
    }
  };
  const toggle = async (s: Supplier) => {
    try {
      await actions.status.mutateAsync({ id: s.id, isActive: !s.is_active });
    } catch (x) {
      fail(x);
    }
  };
  return (
    <div className="space-y-4">
      {canManage && <Card>
        <form onSubmit={save} className="grid gap-3 md:grid-cols-3">
          <h2 className="font-bold md:col-span-3">
            {editing ? "Modifier le fournisseur" : "Nouveau fournisseur"}
          </h2>
          {(
            [
              ["name", "Nom"],
              ["code", "Code"],
              ["contactName", "Contact"],
              ["phone", "Téléphone"],
              ["email", "E-mail"],
              ["city", "Ville"],
              ["country", "Pays"],
              ["taxIdentifier", "Identifiant fiscal"],
              ["address", "Adresse"],
            ] as const
          ).map(([k, l]) => (
            <input
              key={k}
              required={k === "name" || k === "code"}
              type={k === "email" ? "email" : "text"}
              className={field}
              placeholder={l}
              value={String(form[k] ?? "")}
              onChange={(e) => setForm({ ...form, [k]: e.target.value })}
            />
          ))}
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isPartsSupplier} onChange={e=>setForm({...form,isPartsSupplier:e.target.checked})}/>Fournisseur de pièces</label>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isVehicleSupplier} onChange={e=>setForm({...form,isVehicleSupplier:e.target.checked})}/>Fournisseur de véhicules</label>
          <div className="flex gap-2 md:col-span-3">
            <Button
              type="submit"
              loading={actions.create.isPending || actions.update.isPending}
            >
              Enregistrer
            </Button>
            {editing && (
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setEditing(null);
                  setForm(emptySupplier);
                }}
              >
                Annuler
              </Button>
            )}
          </div>
        </form>
      </Card>}
      <label className="relative block">
        <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
        <input
          className={`${field} w-full pl-9`}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Rechercher nom, code, contact, téléphone…"
        />
      </label>
      {q.isError && (
        <p className="rounded bg-red-50 p-3 text-sm text-red-700">
          {q.error.message}
        </p>
      )}
      <div className="grid gap-3 md:grid-cols-2">
        {q.data?.map((s) => (
          <Card key={s.id}>
            <div className="flex justify-between">
              <div>
                <b>{s.name}</b>
                <p className="text-xs text-slate-500">
                  {s.code} · {s.contact_name || "Aucun contact"}
                </p>
              </div>
              <Badge variant={s.is_active ? "success" : "default"}>
                {s.is_active ? "Actif" : "Inactif"}
              </Badge>
            </div>
            <p className="mt-2 text-xs">
              {s.phone || "—"} · {s.email || "—"}
            </p>
            <div className="mt-2 flex gap-2"><Badge variant={s.is_parts_supplier?"primary":"default"}>Pièces : {s.is_parts_supplier?"Oui":"Non"}</Badge><Badge variant={s.is_vehicle_supplier?"primary":"default"}>Véhicules : {s.is_vehicle_supplier?"Oui":"Non"}</Badge></div>
            {canManage && <div className="mt-3 flex gap-2 border-t pt-3">
              <Button size="xs" variant="outline" onClick={() => edit(s)}>
                Modifier
              </Button>
              <Button
                size="xs"
                variant={s.is_active ? "danger" : "success"}
                onClick={() => toggle(s)}
              >
                {s.is_active ? "Désactiver" : "Activer"}
              </Button>
            </div>}
          </Card>
        ))}
      </div>
    </div>
  );
};
export const BaysSettings = () => {
  const agency = useAuthStore((s) => s.currentAgency),
    canManage = useAuthStore((s) => s.can("workshop.resources.manage")),
    q = useSettingsBaysQuery(agency?.id),
    actions = useBaySettingsActions(),
    toast = useUiStore((s) => s.addToast),
    [form, setForm] = useState({ name: "", bayType: "", capacity: 1 }),
    [editing, setEditing] = useState<Bay | null>(null);
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editing)
        await actions.update.mutateAsync({
          id: editing.id,
          agencyId: agency?.id,
          ...form,
          status: editing.status,
        });
      else
        await actions.create.mutateAsync({
          agencyId: agency?.id,
          ...form,
          status: "available",
        });
      setEditing(null);
      setForm({ name: "", bayType: "", capacity: 1 });
    } catch (x) {
      toast({
        type: "error",
        title: "Opération pont impossible",
        description: x instanceof Error ? x.message : "Erreur API",
      });
    }
  };
  const toggle = async (b: Bay) => {
    try {
      await actions.update.mutateAsync({
        id: b.id,
        agencyId: agency?.id,
        status: b.status === "inactive" ? "available" : "inactive",
      });
    } catch (x) {
      toast({
        type: "error",
        title: "Statut impossible",
        description: x instanceof Error ? x.message : "Erreur API",
      });
    }
  };
  return (
    <div className="space-y-4">
      {canManage && <Card>
        <form onSubmit={save} className="grid gap-3 md:grid-cols-4">
          <input
            required
            className={field}
            placeholder="Nom du pont / poste"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
          <input
            className={field}
            placeholder="Type"
            value={form.bayType}
            onChange={(e) => setForm({ ...form, bayType: e.target.value })}
          />
          <input
            className={field}
            type="number"
            min="1"
            value={form.capacity}
            onChange={(e) =>
              setForm({ ...form, capacity: Number(e.target.value) })
            }
          />
          <Button type="submit">{editing ? "Enregistrer" : "Créer"}</Button>
        </form>
      </Card>}
      <div className="grid gap-3 md:grid-cols-2">
        {q.data?.map((b) => (
          <Card key={b.id}>
            <div className="flex justify-between">
              <div>
                <b>{b.name}</b>
                <p className="text-xs text-slate-500">
                  {b.bay_type || "Poste atelier"} · capacité {b.capacity}
                </p>
              </div>
              <Badge variant={b.status === "available" ? "success" : "default"}>
                {b.status}
              </Badge>
            </div>
            {canManage && <div className="mt-3 flex gap-2 border-t pt-3">
              <Button
                size="xs"
                variant="outline"
                onClick={() => {
                  setEditing(b);
                  setForm({
                    name: b.name,
                    bayType: b.bay_type ?? "",
                    capacity: b.capacity,
                  });
                }}
              >
                Modifier
              </Button>
              <Button
                size="xs"
                variant={b.status === "inactive" ? "success" : "danger"}
                disabled={b.occupied_now}
                onClick={() => toggle(b)}
              >
                {b.status === "inactive" ? "Activer" : "Désactiver"}
              </Button>
            </div>}
          </Card>
        ))}
      </div>
    </div>
  );
};
